// program showing the concept of switch control statement

class Switch1{
    public static void main(String args[]){
        switch(1)
        {
            case 1 : System.out.println("case 1 executes");
                        break;
            case 2 : System.out.println("case 2 executes");
                        break;
            default : System.out.println("default case executes");
                        break;
        }
    }
}