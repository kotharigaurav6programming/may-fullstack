// Program showing the concept of function

class Fun1{
    /*user defined function*/
    void myFun(){
        System.out.println("Hello user");
    }

    public static void main(String args[]){
        Fun1 obj = new Fun1();
        obj.myFun();
    }
}