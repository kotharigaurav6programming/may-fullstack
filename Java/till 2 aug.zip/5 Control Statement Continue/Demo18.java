// program showing the concept of while loop

class Demo18{
    public static void main(String args[]){
        int i=1; // initialization

        System.out.println("Before while loop");
        while(i<=10) // condition
        {
            System.out.println("i : "+i);
            i++; // inc | dec
        }
        System.out.println("After while loop");
    }
}