Loops:
------
Looping is the process of performing same task or some task in an iterative or repetative manner untill certain condition is satisfied.

There are 2 types of loops : 

a. Entry control loop : Where condition is checked at the time of entry. Ex: for loop and while loop

for loop : when we already know in advance that how many times we have to executes our loop.
Ex : table of a number

while loop : when we do not know in advance that how many times we have to executes our loop.
Ex : revering a number

b. Exit control loop : Where condition is checked at the time of exit. Ex : do while loop

do while loop : whether condition is true or false, do while loop may executes atleast once.