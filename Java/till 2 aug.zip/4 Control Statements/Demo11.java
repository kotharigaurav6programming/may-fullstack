// program showing the concept of if statement
class Demo11{
    public static void main(String args[]){

        System.out.println("statement 1");
            if(false)
                System.out.println("statement 2");

            System.out.println("statement 3");
            System.out.println("statement 4");
        System.out.println("statement 5");
    }
}