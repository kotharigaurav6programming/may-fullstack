// example of primitive type casting 

class Demo6{
    public static void main(String args[]){
            byte a = 5;
            byte b = 6;
            byte c = (byte)(a+b); 
            System.out.println("c : "+c);

            int d = a+b; 
            System.out.println("d : "+d);
    }
}