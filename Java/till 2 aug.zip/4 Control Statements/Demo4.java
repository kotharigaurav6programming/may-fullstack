        Primitive Type Casting
        ----------------------

        Datatypes
   _________|_________
   |                  |
Primitive datatype   non primitive datatype          
   |                    |
primitive             upcasting & downcasting
type casting            

Primitive Type Casting : Conversion of one datatype(primitive datatype) into another datatype(primitive datatype) is known as primitive type casting, but make sure both datatypes are of primitive datatypes. 

Types of Primitive type casting : 
There are two types of Primitive type casting :-
a. Implicit type casting
b. Explicit type casting











