// program showing the concept of Shorthand operator

class Demo3{
    public static void main(String args[]){
        int a = 5, b = 2, c = 625;
        
        a += 100; // a = a+100 
        System.out.println("value of a : "+a);

        b *= 25; // b = b*25 
        System.out.println("value of b : "+b);

        c /= 25; // c = c/25 
        System.out.println("value of c : "+c);

    }
}