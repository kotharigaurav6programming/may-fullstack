// program showing the concept of arithmetic operator

class Demo1{
    public static void main(String args[]){
        int a = 5, b = 2, c;
        
        c = a+b;
        System.out.println(a+" + "+b+" = "+c);

        c = a-b;
        System.out.println(a+" - "+b+" = "+c);

        c = a*b;
        System.out.println(a+" * "+b+" = "+c);

        c = a/b;
        System.out.println(a+" / "+b+" = "+c);

        c = a%b;
        System.out.println(a+" % "+b+" = "+c);

    }
}