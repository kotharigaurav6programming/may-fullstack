How to take values from user ? 
----------------------------
In case of Java : 

Types of values  | Method required

boolean             nextBoolean()
byte                nextByte()                
int                 nextInt()
short               nextShort()
long                nextLong()    
float               nextFloat()
double              nextDouble()
String  
    |-- one word    next()
    |-- sentence    nextLine()
char                next().charAt(0)