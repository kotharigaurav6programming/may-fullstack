// program showing the concept of increment decrement operator

class Demo4{
    public static void main(String args[]){
        int a=10,b=20,c=5,d=-4;

        System.out.println("a++ : "+a++);
        System.out.println("++b : "+(++b));
        System.out.println("c-- : "+c--);
        System.out.println("--d : "+--d);

    }
}