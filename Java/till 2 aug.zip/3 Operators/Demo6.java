// program showing the concept of simplle interest

class Demo6{
    public static void main(String args[]){
        int p = 1000,t=2;
        double r = 2.50;

        double si = (p*r*t)/100;
        System.out.println("Simple interest : "+si);
    }
}
        
        /*
            Formula : simple interest
            si = (p*r*t)/100; 
        */
