// basic example

class Demo5{
    public static void main(String args[]){
        int a=100;
        int b=200;
        System.out.print("sqrt : "+Math.sqrt(2)+"\n");
        System.out.print("sqrt : "+Math.abs(-72));
        System.out.print("\nsum : "+a+b);
        System.out.print("\nsum : "+(a+b)+"\n");
        System.out.print(a+b+" : sum");
    }
}
